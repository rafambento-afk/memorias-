# Memórias 

A Pen created on CodePen.

Original URL: [https://codepen.io/Rafael-Mantelato-Bento/pen/wBJBddB](https://codepen.io/Rafael-Mantelato-Bento/pen/wBJBddB).

inspired by https://x.com/Rownock_Hasan/status/2053478438326206905

photo by dokae on unsplash: https://unsplash.com/@dokae